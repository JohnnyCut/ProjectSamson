-- phpMyAdmin SQL Dump
-- version 3.4.5
-- http://www.phpmyadmin.net
--
-- Client: localhost
-- Généré le : Ven 18 Août 2017 à 14:28
-- Version du serveur: 5.5.16
-- Version de PHP: 5.3.8

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Base de données: `seriedb`
--

-- --------------------------------------------------------

--
-- Structure de la table `fichetv`
--

CREATE TABLE IF NOT EXISTS `fichetv` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL,
  `slug` varchar(50) NOT NULL,
  `categorie` varchar(30) NOT NULL,
  `statut` varchar(30) NOT NULL,
  `nombre_saisons` int(11) NOT NULL,
  `synopsis` text NOT NULL,
  `link` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf16 AUTO_INCREMENT=11 ;

--
-- Contenu de la table `fichetv`
--

INSERT INTO `fichetv` (`id`, `name`, `slug`, `categorie`, `statut`, `nombre_saisons`, `synopsis`, `link`) VALUES
(1, 'Game of Thrones', 'game-of-thrones', 'Fantastique', 'En cours', 7, 'Sur le continent de Westeros, le roi Robert Baratheon gouverne le Royaume des Sept Couronnes depuis plus de dix-sept ans, à la suite de la rébellion qu''il a menée contre le « roi fou » Aerys II Targaryen. Jon Arryn, époux de la sœur de Lady Catelyn Stark, Lady Arryn, son guide et principal conseiller, vient de décéder, et le roi part alors dans le nord du royaume demander à son vieil ami Eddard « Ned » Stark de remplacer leur regretté mentor au poste de Main du roi. Ned, seigneur suzerain du nord depuis Winterfell et de la maison Stark, est peu désireux de quitter ses terres. Mais il accepte à contre-cœur de partir pour la capitale Port-Réal avec ses deux filles, Sansa et Arya. Juste avant leur départ pour le sud, Bran, l''un des jeunes fils d''Eddard, est poussé de l''une des tours de Winterfell après avoir été témoin de la liaison incestueuse de la reine Cersei Baratheon et son frère jumeau, Jaime Lannister. Leur frère, Tyrion Lannister, surnommé « le gnome », est alors accusé du crime par Lady Catelyn Stark.\r\nAu nord-ouest de Westeros, le jeune bâtard de Ned Stark, Jon Snow, se prépare à intégrer la fameuse Garde de nuit. Depuis plus de 8 000 ans, cette confrérie protège et défend le royaume de ce qui vit de l''autre côté du Mur, un gigantesque édifice fait de glace, de pierre et de magie, formant la frontière septentrionale entre les contrées glacées du nord et les Sept Couronnes. Si les Sauvageons ne sont pas une menace directe, le retour d''une race d''anciennes créatures appelée les Marcheurs blancs est en revanche beaucoup plus inquiétant.\r\nSur le continent d''Essos, au sud-est au-delà du Détroit, l''héritier « légitime » en exil des Sept Couronnes, Viserys Targaryen, se prépare à reconquérir le royaume. Prêt à tout, il marie sa jeune sœur, la princesse Daenerys Targaryen, à Khal Drogo, seigneur de guerre des Dothrakis, afin d''obtenir le soutien de la puissante horde de cavaliers nomades qu''il dirige. Mais le lunatique Viserys va hériter du même sort que celui de ses parents, laissant à Daenerys le projet de recouvrer sa place sur le Trône de fer, aidée en cela par ses trois dragons.\r\n', 'https://upload.wikimedia.org/wikipedia/commons/thumb/2/2e/Game_of_Thrones_2011_logo.svg/langfr-1000px-Game_of_Thrones_2011_logo.svg.png'),
(2, 'Breaking Bad', 'breaking-bad', 'Drame', 'Terminée', 5, 'Walter « Walt » White est professeur de chimie dans un lycée, et vit avec son fils handicapé et sa femme enceinte à Albuquerque, au Nouveau-Mexique. Lorsqu''on lui diagnostique un cancer du poumon en phase terminale avec une espérance de vie estimée à deux ans, tout s''effondre pour lui. Il décide alors de mettre en place un laboratoire et un trafic de méthamphétamine pour assurer un avenir financier confortable à sa famille après sa mort, en s''associant à Jesse Pinkman, un de ses anciens élèves devenu petit trafiquant.', 'https://upload.wikimedia.org/wikipedia/commons/thumb/7/77/Breaking_Bad_logo.svg/langfr-369px-Breaking_Bad_logo.svg.png'),
(3, 'The Big Bang Theory', 'the-big-bang-theory', 'Comédie', 'En cours', 10, 'Leonard Hofstadter et Sheldon Cooper vivent en colocation à Pasadena, ville de l''agglomération de Los Angeles. Ce sont tous deux des physiciens surdoués, « geeks » de surcroît. C''est d''ailleurs autour de cela qu''est axée la majeure partie comique de la série. Ils partagent quasiment tout leur temps libre avec leurs deux amis Howard Wolowitz et Rajesh Koothrappali pour jouer à des jeux vidéo comme Halo, organiser un marathon de la saga Star Wars, jouer à des jeux de société ou de rôles comme le Boggle klingon, Donjons et Dragons, voire discuter de théories scientifiques très complexes.\r\nLeur univers routinier est perturbé lorsqu''une jolie jeune femme, Penny, s''installe dans l''appartement d''en face. Leonard a immédiatement des vues sur elle et va tout faire pour la séduire ainsi que l''intégrer au groupe et à son univers, auquel elle ne connaît rien.\r\n', 'https://upload.wikimedia.org/wikipedia/fr/6/69/BigBangTheory_Logo.png'),
(4, 'Narcos', 'narcos', 'Drame', 'En cours', 2, 'À la fin des années 1970, les États-Unis et la Colombie se lancent dans une lutte acharnée contre le cartel de drogue de Medellín. Steve Murphy, jeune agent de la DEA fait son possible pour faire tomber Pablo Escobar et ses hommes, malgré l''importante corruption policière qui gangrène la Colombie. Cette lutte se mêle à celle des États-Unis contre le communisme et à de nombreux autres intérêts politiques.', 'https://upload.wikimedia.org/wikipedia/commons/c/c4/Narcoslogo.jpg'),
(5, 'The walking dead', 'the-walking-dead', 'Fantastique', 'En cours', 7, 'Après une épidémie post-apocalyptique ayant transformé la quasi-totalité de la population américaine et mondiale en mort-vivants ou « rôdeurs », un groupe d''hommes et de femmes mené par l''adjoint du shérif du comté de Kings (en Géorgie), Rick Grimes, qui se réveille tout juste d''un coma, tente de survivre…\r\nEnsemble, ils vont devoir tant bien que mal faire face à ce nouveau monde devenu méconnaissable, à travers leur périple dans le Sud profond des États-Unis.\r\n', 'https://upload.wikimedia.org/wikipedia/commons/thumb/e/ef/The_Walking_Dead_2010_logo.svg/langfr-1000px-The_Walking_Dead_2010_logo.svg.png'),
(6, 'Homeland', 'homeland', 'Drame', 'En cours', 6, 'Après une confidence de l''un de ses informateurs, Carrie Mathison, agent de la Central Intelligence Agency (CIA) souffrant secrètement d''un trouble bipolaire, est la seule persuadée que Nicholas Brody, marine américain libéré lors d''une opération commando en 2011 au terme de huit ans de détention par Al-Qaïda, est radicalisé et représente un risque pour la sécurité nationale américaine. Sa persévérance pour suivre le comportement du soldat, qui vire à l''obsession maladive, va l''amener à déterminer si le traumatisme de Brody est réel, ou s''il participe à une conspiration visant les États-Unis.', 'https://upload.wikimedia.org/wikipedia/commons/8/82/Homeland_Logo_frameless_2014-04-06_23-44.png'),
(7, 'Les 100', 'les-100', 'fantastique', 'en cours', 4, 'La série débute 97 ans après un holocauste nucléaire qui a décimé la population de la Terre, détruisant toute civilisation. Les seuls survivants étaient les quelques personnes se situant dans une des douze stations spatiales étant en orbite à ce moment-là. Depuis, les douze stations spatiales ont été reliées entre elles et réorganisées afin de garder leurs habitants en vie. Ce groupe de stations se nomme l''ARCHE. Celle-ci compte maintenant plus de 2 400 habitants. Trois générations se sont ensuite succédé dans l''espace mais les ressources s''épuisent. Des mesures draconiennes ont donc été prises : la peine de mort chez les majeurs et le maximum d''un enfant par couple sont à l''ordre du jour et les dirigeants de l''Arche font des choix impitoyables pour assurer leur futur, notamment exiler secrètement un groupe de 100 prisonniers mineurs à la surface de la Terre pour savoir si elle est redevenue habitable. Pour la première fois depuis près d''un siècle, des humains retournent sur la planète Terre.\r\n\r\nParmi les 100 exilés, il y a Clarke, la brillante adolescente, fille de l''officier médical en chef de l''Arche ; Wells, le fils du Chancelier ; Finn le trompe-la-mort et le duo Bellamy et Octavia, que la fraternité a toujours poussé à enfreindre les règles. Privés de communication avec la Terre, les dirigeants de l''Arche – la mère de Clarke, Abby, le chancelier Jaha et son sombre commandant en second, Kane – doivent prendre des décisions difficiles au sujet de la vie, de la mort et de la survie de l''espèce humaine. Pour les 100 survivants, la Terre est une planète étrangère dont ils ignorent tout, c''est un royaume mystérieux qui peut être magique un instant et mortel l''instant suivant. La survie de l''espèce humaine repose sur les 100, ils doivent parvenir à transcender leurs différences afin de survivre.', 'https://upload.wikimedia.org/wikipedia/fr/e/e1/The_100.jpg'),
(8, 'six feet under', 'six-feet-under', 'drame', 'Terminée', 5, 'Six Feet Under raconte le quotidien d''une famille, les Fisher, qui sont à la tête d''une société de pompes funèbres à Los Angeles, Fisher & Sons, fondée par le père de famille Nathaniel Fisher (Richard Jenkins). À sa mort, ses deux fils, Nathaniel Jr (Peter Krause), qui a toujours dit ne jamais vouloir prendre la suite de son père, et David (Michael C. Hall), homosexuel introverti, reprennent l''entreprise familiale dont ils viennent d''hériter ; Ruth (Frances Conroy), sa veuve, doit assumer son rôle de femme ; Claire (Lauren Ambrose), benjamine de la famille, s''efforce de trouver sa voie.', 'https://upload.wikimedia.org/wikipedia/fr/7/75/Logo_six_feet_unde.jpg'),
(10, 'How I met your mother', 'how-i-met-your-mother', 'Comedie', 'Terminée', 9, 'La série débute en 2030, lorsque Ted Mosby raconte à ses deux enfants comment il a rencontré leur mère. Il se remémore ses jeunes années, et le pilote fait place aux souvenirs de Ted en 2005, où il apprend que son meilleur ami Marshall Eriksen va demander à Lily Aldrin de l’épouser. Ted se demande quand il rencontrera sa future épouse. C’est alors qu’il rencontre Robin Scherbatsky lors de sa dernière sortie au bar où il a l’habitude d’aller, le MacLaren''s Pub, où un de ses amis, Barney Stinson, l’aide à faire des rencontres.\r\n\r\nEt c''est ainsi que commence l''incroyable et très longue histoire de Ted, jusqu''à sa rencontre avec la fameuse mère de ses enfants.', 'https://upload.wikimedia.org/wikipedia/commons/thumb/f/fd/HowIMetYourMother.svg/langfr-704px-HowIMetYourMother.svg.png');

-- --------------------------------------------------------

--
-- Structure de la table `user`
--

CREATE TABLE IF NOT EXISTS `user` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `login` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL,
  `name` varchar(50) NOT NULL,
  `mail` varchar(50) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf16 AUTO_INCREMENT=3 ;

--
-- Contenu de la table `user`
--

INSERT INTO `user` (`id`, `login`, `password`, `name`, `mail`) VALUES
(1, 'vinh', 'password', 'vinh', 'vinh@example.com'),
(2, 'gregoire', 'password', 'gregoire', 'gregoire@example.com');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
